import java.util.Random;

enum ResultadoBusqueda {
	RUIDO("Haces ruido",1), BOTIQUIN("Jugador encuentra botiquín",2),
	PROTECCION("Jugador encuentra botiquín",3), ARMA("Jugador encuentra arma",4),
	NADA("Acción de búsqueda no resuelta",0),
	ERROR("Ha habido algún problema",-1); 
	
	private String descripcion;
	private int numeroBusqueda;
	
	private ResultadoBusqueda (String descripcion, int numeroBusqueda){
		this.descripcion = descripcion;
		this.numeroBusqueda = numeroBusqueda;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public int getNumeroBusqueda() {
		return numeroBusqueda;
	} 
}

enum ResultadoRuido {
	NADA("Nadie te oye",0),ZOMBIE1("Llamas a 1 zombie",1), 
	ZOMBIE2("Llamas a 2 zombies",2), ERROR("Ha habido algún problema",-1); 
	
	private String descripcion;
	private int numeroRuido;
	
	private ResultadoRuido (String descripcion, int numeroRuido){
		this.descripcion = descripcion;
		this.numeroRuido = numeroRuido;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public int getNumeroRuido() {
		return numeroRuido;
	} 
}

public class PruebasRecibidas
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
	/*
	 * Realizamos la tirada de ruido (D100):
	 * 
	 * 1 <= ruido <= 40: no pasa nada
	 * 40 < ruido <= 80: +1 zombie
	 * 80 < ruido <= 100: +2 zombies
	 * 
	 * */
	public static ResultadoRuido hacerRuido(int ruido) 
	{
		ResultadoRuido resultado = ResultadoRuido.ERROR;
		
		if (ruido >=1 && ruido <= 30)
		{
			System.out.println(ResultadoRuido.ZOMBIE2.getNumeroRuido() + ": " + ResultadoRuido.ZOMBIE2.getDescripcion());
			
			resultado = ResultadoRuido.ZOMBIE2;
		}
		else if (ruido > 40 && ruido < 80)
		{
			// Añadiríamos un zombie activo a la habitación
			//this.numeroZombisActivos++;
			System.out.println(ResultadoRuido.ZOMBIE1.getNumeroRuido() + ": " + ResultadoRuido.ZOMBIE1.getDescripcion());
			resultado = ResultadoRuido.ZOMBIE1;
		}
		else if(ruido > 80 && ruido <= 100)
		{
			// Añadiríamos dos zombies activos a la habitación
			//this.numeroZombisActivos += 2;
			System.out.println(ResultadoRuido.NADA.getNumeroRuido() + ": " + ResultadoRuido.NADA.getDescripcion());
			resultado = ResultadoRuido.NADA;
		}
		
		return resultado;
	}

	/*
	 * Realizamos la tirada de búsqueda (D100):
	 * 
	 * 1 <= tirada <= 75: hacemos ruido (posibilidad de llamar a un zombie)
	 * 75 < tirada <= 90: botiquín
	 * 90 < tirada <= 95: protección
	 * 95 < tirada <= 100: arma
	 * */
	public static ResultadoBusqueda buscarObjetos(int resultadoBusqueda) 
	{	
		ResultadoBusqueda resultado = ResultadoBusqueda.ERROR;
		
		// Resto un intento de búsqueda
		//this.intentosBusquedaActuales--;
		
		if (resultadoBusqueda > 1 && resultadoBusqueda <= 75)
		{
			System.out.println(ResultadoBusqueda.BOTIQUIN.getNumeroBusqueda() + ": " + ResultadoBusqueda.BOTIQUIN.getDescripcion());
			Random rnd = new Random();
			int ruido = rnd.nextInt(100)+1;
			hacerRuido(ruido);
			resultado = ResultadoBusqueda.BOTIQUIN;
		}
		else if (resultadoBusqueda > 75 && resultadoBusqueda < 90)
		{
			// Habilito el botiquín para el superviviente
			//this.botiquin = true;
			System.out.println(ResultadoBusqueda.RUIDO.getNumeroBusqueda() + ": " + ResultadoBusqueda.RUIDO.getDescripcion());
			
			resultado = ResultadoBusqueda.RUIDO;
		}
		else if (resultadoBusqueda > 90 && resultadoBusqueda <= 95)
		{
			// Añado una protección al jugador
			//this.protecciones++;
			System.out.println(ResultadoBusqueda.ARMA.getNumeroBusqueda() + ": " + ResultadoBusqueda.ARMA.getDescripcion());
			resultado = ResultadoBusqueda.ARMA;
		}
		else if (resultadoBusqueda > 95 && resultadoBusqueda < 100)
		{
			// Añado un arma al jugador
			//this.armas++;
			System.out.println(ResultadoBusqueda.ARMA.getNumeroBusqueda() + ": " + ResultadoBusqueda.ARMA.getDescripcion());
			resultado = ResultadoBusqueda.ARMA;
		}
		
		return resultado;
	}
	
	
}